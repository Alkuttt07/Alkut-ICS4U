import pygame

pygame.init()
pygame.display.set_mode((1200, 800))
cursor_img = pygame.image.load("menu/menu images/sword_cursor.png").convert_alpha()
cursor_img = pygame.transform.scale(cursor_img, (30, 30))
# Create the cursor: (hotspot_x, hotspot_y), surface
pygame.mouse.set_cursor((0, 0), cursor_img)


screen1 = pygame.display.set_mode((1200, 800))

dungeon_menu = pygame.image.load('menu/menu images/dungeon_menu.png').convert()
title = pygame.image.load('menu/menu images/title.png').convert_alpha()
title = pygame.transform.scale(title, (500, 100))
enter_dungeon = pygame.image.load('menu/menu images/enter_dungeon.png').convert_alpha()
enter_dungeon = pygame.transform.scale(enter_dungeon, (612, 408))
settings = pygame.image.load('menu/menu images/settings.png').convert_alpha()
settings = pygame.transform.scale(settings, (612, 408))    
quit = pygame.image.load('menu/menu images/quit.png').convert_alpha()
quit = pygame.transform.scale(quit, (612, 408))

while True:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()

    screen1.blit(dungeon_menu, (0, 0))
    screen1.blit(title, (294, 0))
    screen1.blit(enter_dungeon, (294, 0))
    screen1.blit(settings, (294, 0))
    screen1.blit(quit, (294, 0))
    
    
    pygame.display.update()
    pygame.time.Clock().tick(60)

    
        